import './config.js';
import './logger.js';

const log = globalThis.logger.log;
const logError = globalThis.logger.error;
const logWarn = globalThis.logger.warn;

const MAX_DURATION_MS = (globalThis.LoomoConfig?.MAX_RECORDING_MINUTES || 4) * 60 * 1000;
const WARNING_DURATION_MS = (globalThis.LoomoConfig?.WARNING_RECORDING_MINUTES || 2) * 60 * 1000;

self.addEventListener('error', (event) => {
  logError(`[background] Unhandled error: ${event.message} at ${event.filename}:${event.lineno}`);
});
self.addEventListener('unhandledrejection', (event) => {
  logError(`[background] Unhandled promise rejection: ${event.reason}`);
});

// State Perekaman Global di Background
let isRecording = false;
let isPaused = false;
let startTime = 0;
let accumulatedTime = 0;
let finalDuration = 0;
let activeTabId = null;

let logs = [];
let networkRequests = [];
let userActions = [];

let maxDurationTimer = null;
let warningShown = false;

// Helper untuk sinkronisasi state ke storage (mengatasi service worker inactivity/idle termination)
function withRecordingState(callback) {
  chrome.storage.local.get([
    'rec_isRecording',
    'rec_isPaused',
    'rec_startTime',
    'rec_accumulatedTime',
    'rec_finalDuration',
    'rec_activeTabId',
    'rec_logs',
    'rec_networkRequests',
    'rec_userActions'
  ], (res) => {
    isRecording = !!res.rec_isRecording;
    isPaused = !!res.rec_isPaused;
    startTime = res.rec_startTime || 0;
    accumulatedTime = res.rec_accumulatedTime || 0;
    finalDuration = res.rec_finalDuration || 0;
    activeTabId = res.rec_activeTabId || null;
    logs = res.rec_logs || [];
    networkRequests = res.rec_networkRequests || [];
    userActions = res.rec_userActions || [];
    callback();
  });
}

function updateRecordingState(cb) {
  chrome.storage.local.set({
    rec_isRecording: isRecording,
    rec_isPaused: isPaused,
    rec_startTime: startTime,
    rec_accumulatedTime: accumulatedTime,
    rec_finalDuration: finalDuration,
    rec_activeTabId: activeTabId,
    rec_logs: logs,
    rec_networkRequests: networkRequests,
    rec_userActions: userActions
  }, () => {
    if (cb) cb();
  });
}

function clearRecordingState(cb) {
  isRecording = false;
  isPaused = false;
  startTime = 0;
  accumulatedTime = 0;
  finalDuration = 0;
  activeTabId = null;
  logs = [];
  networkRequests = [];
  userActions = [];
  warningShown = false;
  if (maxDurationTimer) {
    clearTimeout(maxDurationTimer);
    maxDurationTimer = null;
  }
  chrome.storage.local.remove([
    'rec_isRecording',
    'rec_isPaused',
    'rec_startTime',
    'rec_accumulatedTime',
    'rec_finalDuration',
    'rec_activeTabId',
    'rec_logs',
    'rec_networkRequests',
    'rec_userActions'
  ], () => {
    if (cb) cb();
  });
}

// Mendengarkan pesan dari Content Script, Popup, dan Offscreen Document
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Handle keep-alive ping from offscreen
  if (message.source === 'jam-extension-offscreen' && message.action === 'PING') {
    return false;
  }

  // Handle closing the current popup/window
  if (message.action === 'CLOSE_CURRENT_WINDOW') {
    if (sender && sender.tab && typeof sender.tab.windowId !== 'undefined') {
      chrome.windows.remove(sender.tab.windowId);
    }
    return false;
  }

  // 1. Log Penyadapan Halaman Target (dari content.js)
  if (message.source === 'jam-extension-content') {
    if (message.type === 'CONSOLE_LOG' || message.type === 'NETWORK_REQUEST' || message.type === 'USER_ACTION') {
      withRecordingState(() => {
        if (isRecording) {
          if (message.type === 'CONSOLE_LOG') {
            logs.push(message.payload);
          } else if (message.type === 'NETWORK_REQUEST') {
            networkRequests.push(message.payload);
          } else if (message.type === 'USER_ACTION') {
            userActions.push(message.payload);
          }
          updateRecordingState();
        }
      });
      return false; // non-blocking logging
    }
  }

  // 2. Instruksi Kontrol dari Popup (popup.js) atau Content Script (floating control bar)
  if (message.source === 'jam-extension-popup' || message.source === 'jam-extension-content') {
    if (message.action === 'START_RECORDING') {
      let targetTabId = message.payload?.tabId;
      if (!targetTabId && sender && sender.tab) {
        targetTabId = sender.tab.id;
      }
      if (!targetTabId) {
        sendResponse({ success: false, error: 'Target tab ID not found.' });
        return false;
      }
      chrome.tabCapture.getMediaStreamId({ targetTabId: targetTabId }, (streamId) => {
        if (chrome.runtime.lastError) {
          logWarn('Gagal mengambil streamId tabCapture:', chrome.runtime.lastError.message);
          startRecordingFlow(targetTabId, null, sendResponse);
        } else {
          startRecordingFlow(targetTabId, streamId, sendResponse);
        }
      });
      return true; // async response
    } else if (message.action === 'STOP_RECORDING') {
      withRecordingState(() => {
        stopRecordingFlow(sendResponse);
      });
      return true; // async response
    } else if (message.action === 'PAUSE_RECORDING') {
      withRecordingState(() => {
        if (isRecording && !isPaused) {
          accumulatedTime += (Date.now() - startTime);
          isPaused = true;
          if (maxDurationTimer) {
            clearTimeout(maxDurationTimer);
            maxDurationTimer = null;
          }
          updateRecordingState(() => {
            chrome.runtime.sendMessage({
              source: 'jam-extension-background',
              action: 'PAUSE_OFFSCREEN_CAPTURE'
            });
            sendResponse({ success: true });
          });
        } else {
          sendResponse({ success: false, error: 'Cannot pause: not recording or already paused.' });
        }
      });
      return true;
    } else if (message.action === 'RESUME_RECORDING') {
      withRecordingState(() => {
        if (isRecording && isPaused) {
          startTime = Date.now();
          isPaused = false;
          const remainingTime = MAX_DURATION_MS - accumulatedTime;
          const timeUntilWarning = WARNING_DURATION_MS - accumulatedTime;
          
          if (timeUntilWarning > 0 && !warningShown) {
            maxDurationTimer = setTimeout(() => {
              checkDurationWarningAndStop();
            }, timeUntilWarning);
          } else if (remainingTime > 0) {
            maxDurationTimer = setTimeout(() => {
              checkDurationWarningAndStop();
            }, remainingTime);
          }
          
          updateRecordingState(() => {
            chrome.runtime.sendMessage({
              source: 'jam-extension-background',
              action: 'RESUME_OFFSCREEN_CAPTURE'
            });
            sendResponse({ success: true });
          });
        } else {
          sendResponse({ success: false, error: 'Cannot resume: not paused.' });
        }
      });
      return true;
    } else if (message.action === 'GET_STATUS') {
      withRecordingState(() => {
        let elapsed = 0;
        if (isRecording) {
          if (isPaused) {
            elapsed = Math.round(accumulatedTime / 1000);
          } else {
            elapsed = Math.round((accumulatedTime + (Date.now() - startTime)) / 1000);
          }
        }
        const senderTabId = (sender && sender.tab) ? sender.tab.id : null;
        const isCurrentTabRecording = isRecording && (senderTabId === activeTabId);
        sendResponse({ isRecording, isCurrentTabRecording, isPaused, elapsed });
      });
      return true;
    } else if (message.action === 'START_SCREENSHOT') {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const activeTab = tabs[0];
        if (!activeTab || !activeTab.id) {
          sendResponse({ success: false, error: 'Tidak ada tab aktif yang ditemukan.' });
          return;
        }

        // Cek apakah content script sudah aktif di tab tersebut
        chrome.tabs.sendMessage(activeTab.id, { action: 'PING' }, (pingRes) => {
          if (chrome.runtime.lastError) {
            // Jika belum diinjeksi, injeksi programmatically!
            chrome.scripting.executeScript({
              target: { tabId: activeTab.id },
              files: ['content.js']
            }).then(() => {
              // Tunggu sejenak agar skrip terinisialisasi
              setTimeout(() => {
                chrome.tabs.sendMessage(activeTab.id, {
                  source: 'jam-extension-background',
                  action: 'INIT_SCREENSHOT_SELECTION'
                }, (res) => {
                  if (chrome.runtime.lastError) {
                    sendResponse({ success: false, error: 'Gagal menginisialisasi area tangkapan layar.' });
                  } else {
                    sendResponse({ success: true });
                  }
                });
              }, 150);
            }).catch((err) => {
              sendResponse({ success: false, error: 'Halaman sistem/Chrome Web Store tidak didukung untuk tangkapan layar.' });
            });
          } else {
            // Jika sudah aktif, jalankan perintah
            chrome.tabs.sendMessage(activeTab.id, {
              source: 'jam-extension-background',
              action: 'INIT_SCREENSHOT_SELECTION'
            }, (res) => {
              if (chrome.runtime.lastError) {
                sendResponse({ success: false, error: 'Gagal menginisialisasi area tangkapan layar.' });
              } else {
                sendResponse({ success: true });
              }
            });
          }
        });
      });
      return true;
    } else if (message.action === 'CAPTURE_VISIBLE_TAB') {
      const windowId = (sender && sender.tab) ? sender.tab.windowId : null;
      const performCapture = (winId) => {
        chrome.tabs.captureVisibleTab(winId, { format: 'png' }, (dataUrl) => {
          if (chrome.runtime.lastError) {
            if (winId !== null) {
              // Clear error and fallback to default window capture
              const errMsg = chrome.runtime.lastError.message;
              logWarn('[Jam Extension] captureVisibleTab failed for windowId, falling back to default:', errMsg);
              performCapture(null);
            } else {
              logError(`[background] [Jam Extension] captureVisibleTab error: ${chrome.runtime.lastError.message}`);
              sendResponse({ error: chrome.runtime.lastError.message });
            }
          } else {
            sendResponse({ dataUrl });
          }
        });
      };
      performCapture(windowId);
      return true;
    } else if (message.action === 'SAVE_SCREENSHOT') {
      const { metadata, imageBase64 } = message.payload;
      chrome.storage.local.set({
        pending_jam_metadata: metadata,
        pending_jam_video: imageBase64
      }, () => {
        const backofficeUrl = `${globalThis.LoomoConfig.API_BASE_URL}/editor?id=${metadata.id}&isPopup=true`;
        createCenteredEditorWindow(backofficeUrl);
      });
    }
  }

  // 3. Terima Video Blob dari Offscreen Document langsung via message
  if (message.source === 'jam-extension-offscreen' && message.action === 'VIDEO_BLOB_READY') {
    log('[background] Received VIDEO_BLOB_READY from offscreen');
    const videoBase64 = message.payload?.videoBase64;
    
    if (videoBase64) {
      log('[background] Video blob received, length:', videoBase64.length);
      withRecordingState(() => {
        saveRecordingAndRedirect(videoBase64);
      });
      sendResponse({ success: true });
    } else {
      logError('[background] No video data in payload');
      sendResponse({ success: false, error: 'No video data' });
    }
    return true;
  }

  // 3b (Legacy). Terima Video Blob dari Offscreen Document via Storage (fallback)
  if (message.source === 'jam-extension-offscreen' && message.action === 'VIDEO_BLOB_READY_IN_STORAGE') {
    log('[background] Received VIDEO_BLOB_READY_IN_STORAGE from offscreen');
    withRecordingState(() => {
      chrome.storage.local.get(['pending_video_blob'], (result) => {
        if (chrome.runtime.lastError) {
          logError('[background] Gagal mengambil pending_video_blob dari storage:', chrome.runtime.lastError.message);
          return;
        }
        const videoBase64 = result.pending_video_blob;
        log('[background] Video blob from storage:', videoBase64 ? `${videoBase64.length} bytes` : 'empty');
        chrome.storage.local.remove('pending_video_blob');
        if (videoBase64) {
          log('[background] Calling saveRecordingAndRedirect');
          saveRecordingAndRedirect(videoBase64);
        } else {
          logError('[background] pending_video_blob kosong di storage.');
        }
      });
    });
    return false;
  }

  // 3b. Menerima request upload latar belakang dari content script
  if (message.action === 'BACKGROUND_UPLOAD_START') {
    const { mediaId, uploadUrl, blob, id, title } = message.payload;
    performBackgroundUpload(mediaId, uploadUrl, blob, id, title);
    sendResponse({ success: true });
    return false;
  }

  // 4. Jembatan Impor Data untuk Backoffice LocalStorage
  if (message.action === 'GET_PENDING_JAM') {
    chrome.storage.local.get(['pending_jam_metadata', 'pending_jam_video'], (result) => {
      if (result.pending_jam_metadata) {
        sendResponse({
          metadata: result.pending_jam_metadata,
          videoBase64: result.pending_jam_video
        });
        // Bersihkan storage setelah dibaca agar tidak menumpuk
        chrome.storage.local.remove(['pending_jam_metadata', 'pending_jam_video']);
      } else {
        sendResponse(null);
      }
    });
    return true; // async
  }
});

async function startRecordingFlow(targetTabId, streamId, sendResponse) {
  try {
    activeTabId = targetTabId;
    isRecording = true;
    isPaused = false;
    startTime = Date.now();
    accumulatedTime = 0;
    finalDuration = 0;
    logs = [];
    networkRequests = [];
    userActions = [];
    warningShown = false;

    updateRecordingState(async () => {
      const pingSuccess = await new Promise((resolve) => {
        chrome.tabs.sendMessage(activeTabId, { action: 'PING' }, (res) => {
          if (chrome.runtime.lastError) {
            resolve(false);
          } else {
            resolve(true);
          }
        });
      });

      if (!pingSuccess) {
        try {
          await chrome.scripting.executeScript({
            target: { tabId: activeTabId },
            files: ['content.js']
          });
          await new Promise(r => setTimeout(r, 150));
        } catch (err) {
          logWarn('Gagal melakukan injeksi skrip rekam:', err);
        }
      }

      await chrome.tabs.sendMessage(activeTabId, {
        source: 'jam-extension-background',
        action: 'START_RECORDING'
      }).catch((e) => log('Mungkin skrip belum dimuat pada halaman sistem:', e));

      await createOffscreenDocument();

      chrome.runtime.sendMessage({
        source: 'jam-extension-background',
        action: 'START_OFFSCREEN_CAPTURE',
        payload: { streamId }
      });

      maxDurationTimer = setTimeout(() => {
        checkDurationWarningAndStop();
      }, WARNING_DURATION_MS);

      sendResponse({ success: true });
    });
  } catch (err) {
    logError(`[background] Gagal memulai alur perekaman: ${err.message || String(err)}`);
    clearRecordingState(() => {
      sendResponse({ success: false, error: err.message });
    });
  }
}

function checkDurationWarningAndStop() {
  withRecordingState(() => {
    if (!isRecording) return;

    const currentDuration = isPaused ? accumulatedTime : (accumulatedTime + (Date.now() - startTime));

    if (currentDuration >= MAX_DURATION_MS) {
      log('[background] Max duration 4 minutes reached, auto-stopping recording');
      stopRecordingFlow(() => {});
      return;
    }

    if (currentDuration >= WARNING_DURATION_MS && !warningShown) {
      warningShown = true;
      log('[background] Warning: 2 minutes reached, max 4 minutes');
      if (activeTabId) {
        chrome.tabs.sendMessage(activeTabId, {
          source: 'jam-extension-background',
          action: 'SHOW_DURATION_WARNING',
          payload: { message: 'Recording has reached 2 minutes. Maximum is 4 minutes.' }
        }).catch(() => {});
      }

      maxDurationTimer = setTimeout(() => {
        checkDurationWarningAndStop();
      }, MAX_DURATION_MS - WARNING_DURATION_MS);
    }
  });
}

async function stopRecordingFlow(sendResponse) {
  if (!isRecording) {
    sendResponse({ success: false, error: 'Perekaman tidak aktif.' });
    return;
  }

  log('[background] Stop recording flow started');

  if (isPaused) {
    finalDuration = Math.round(accumulatedTime / 1000);
  } else {
    finalDuration = Math.round((accumulatedTime + (Date.now() - startTime)) / 1000);
  }

  log('[background] Final duration:', finalDuration, 'seconds');

  updateRecordingState(async () => {
    if (activeTabId) {
      log('[background] Sending STOP_RECORDING to tab:', activeTabId);
      await chrome.tabs.sendMessage(activeTabId, {
        source: 'jam-extension-background',
        action: 'STOP_RECORDING'
      }).catch(() => {});
    }

    log('[background] Checking if offscreen exists before sending stop');
    const offscreenUrl = chrome.runtime.getURL('offscreen.html');
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [offscreenUrl]
    });

    if (existingContexts.length > 0) {
      log('[background] Offscreen exists, sending STOP_OFFSCREEN_CAPTURE');
      chrome.runtime.sendMessage({
        source: 'jam-extension-background',
        action: 'STOP_OFFSCREEN_CAPTURE'
      }).catch((err) => {
        logError('[background] Failed to send stop to offscreen:', err);
      });
    } else {
      logWarn('[background] Offscreen document not found, it may have been terminated');
      log('[background] Recording stopped but no video will be saved');
      clearRecordingState();
    }

    sendResponse({ success: true });
  });
}

// Membuat Offscreen Document
async function createOffscreenDocument() {
  const offscreenUrl = chrome.runtime.getURL('offscreen.html');
  
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [offscreenUrl]
  });

  if (existingContexts.length > 0) {
    log('[background] Offscreen document already exists');
    return;
  }

  log('[background] Creating new offscreen document');
  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Merekam layar tab aktif dan mikrofon untuk laporan bug.'
  });
  
  log('[background] Offscreen document created successfully');
}

// Menyimpan Hasil dan Mengarahkan ke Backoffice
function createCenteredEditorWindow(url) {
  chrome.windows.getLastFocused((win) => {
    let winWidth = 1280;
    let winHeight = 720;
    let left = 100;
    let top = 100;
    if (win && typeof win.width === 'number' && typeof win.height === 'number') {
      winWidth = Math.min(1600, Math.round(win.width * 0.9));
      winHeight = Math.min(960, Math.round(win.height * 0.9));
      left = Math.round((win.width - winWidth) / 2 + (win.left || 0));
      top = Math.round((win.height - winHeight) / 2 + (win.top || 0));
    }
    chrome.windows.create({
      url,
      type: 'popup',
      width: winWidth,
      height: winHeight,
      left: Math.max(0, left),
      top: Math.max(0, top)
    }, (newWin) => {
      if (chrome.runtime.lastError) {
        logWarn('Gagal membuat centered window, mencoba fallback:', chrome.runtime.lastError.message);
        chrome.windows.create({
          url,
          type: 'popup'
        });
      }
    });
  });
}

async function saveRecordingAndRedirect(videoDataBase64) {
  log('[background] saveRecordingAndRedirect called with video data:', videoDataBase64 ? `${videoDataBase64.length} bytes` : 'empty');
  
  chrome.offscreen.closeDocument().catch(() => {});
  
  const durationSec = finalDuration || 1;
  log('[background] Creating metadata with duration:', durationSec);
 
  const metadata = {
    id: generateUUID(),
    title: `Loomo Recording - ${new Date().toLocaleDateString('id-ID')} ${new Date().toLocaleTimeString('id-ID')}`,
    createdAt: new Date().toISOString(),
    type: 'recording',
    duration: durationSec || 1,
    systemInfo: {
      browser: 'Google Chrome (Extension)',
      os: 'Linux',
      userAgent: 'Chrome Extension',
      screenResolution: '1920x1080',
      viewportSize: '1280x720',
      locale: 'id-ID'
    },
    logs: logs,
    networkRequests: networkRequests,
    userActions: userActions
  };
 
  log('[background] Metadata created:', metadata.id);
  
  chrome.storage.local.set({
    pending_jam_metadata: metadata,
    pending_jam_video: videoDataBase64
  }, () => {
    log('[background] Data saved to storage, clearing recording state');
    clearRecordingState(() => {
      const backofficeUrl = `${globalThis.LoomoConfig.API_BASE_URL}/editor?id=${metadata.id}&isPopup=true`;
      log('[background] Opening editor window:', backofficeUrl);
      createCenteredEditorWindow(backofficeUrl);
    });
  });
}

function generateUUID() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

async function performBackgroundUpload(mediaId, uploadUrl, blob, id, title) {
  log('[background] Starting background upload to Google Drive for:', title, 'Media ID:', mediaId);
  
  try {
    // 1. Upload directly to Google Drive (PUT request)
    const uploadRes = await fetch(uploadUrl, {
      method: 'PUT',
      body: blob,
      headers: {
        'Content-Type': blob.type || 'video/webm'
      }
    });

    if (!uploadRes.ok) {
      throw new Error(`Google Drive upload failed: ${uploadRes.statusText}`);
    }

    const gMetadata = await uploadRes.json();
    const driveFileId = gMetadata.id;
    log('[background] Google Drive upload success, file ID:', driveFileId);

    // 2. Finalize on server
    const completeRes = await fetch(`${globalThis.LoomoConfig.API_BASE_URL}/api/media/upload/complete`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        mediaId,
        driveFileId,
        fileSize: blob.size
      })
    });

    if (!completeRes.ok) {
      const errText = await completeRes.text();
      throw new Error(`Failed to finalize upload on server: ${errText}`);
    }

    log('[background] Background upload successfully finalized for:', title);

    // 3. Show System Notification (CORS/Permissions allowed)
    chrome.notifications.create(mediaId, {
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'Loomo - Upload Sukses!',
      message: `Video "${title}" berhasil di-upload ke Google Drive.`,
      priority: 2
    });

  } catch (err) {
    logError('[background] Background upload error:', err.message || err);
    
    // Show Error Notification
    chrome.notifications.create(mediaId, {
      type: 'basic',
      iconUrl: 'icon.png',
      title: 'Loomo - Upload Gagal',
      message: `Gagal mengunggah video "${title}": ${err.message || String(err)}`,
      priority: 2
    });
  }
}
