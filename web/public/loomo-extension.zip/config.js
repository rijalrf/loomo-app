// Loomo Capture Engine Configuration
globalThis.LoomoConfig = {
  // Base URL of the Loomo backoffice/web application.
  // Change this to your production domain when deploying.
  API_BASE_URL: 'http://localhost:8999'
};
